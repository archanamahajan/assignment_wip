# Start Mongo server
mongod --dbpath D:\MongoDB\Server\5.0\data
mongo
It will start on port 27017

# Start API server
npm install
npm run startapi
It will start on port 3000

# Start UI server
npm install
ng serve
It will start on port 4200

# Create a DB locally on MongoDB
Open mongo shell
use productInfo
db.product.insertMany() -- product-search-api\data\productType.json
db.material.insertMany() -- product-search-api\data\materialList.json

# Note - Pending task
Left filter panel is fully not functional. Its pendind as need to complete the assignment in one day.