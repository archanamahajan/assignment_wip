import { Component } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'product-search-app';

  constructor(private _router: Router) { }


  onSearch(inputData: any) {
    console.log('onSearch : ', inputData.value);
    if (inputData.value) {
      this._router.navigate(['/product-details', { search: inputData.value }]);
    }
  }
}
