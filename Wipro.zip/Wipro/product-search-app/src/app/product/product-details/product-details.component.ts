import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { ProductService } from '../../services/product.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit, AfterViewInit {

  queryParams: any = {};
  material: any = [];
  totalCount!: number;
  displayedColumns: string[] = ['name', 'productType', 'description', 'status'];
  dataSource = new MatTableDataSource<any>(this.material);
  productTypesCheck = [
    { name: 'Foam', completed: false, color: 'primary' },
    { name: 'Adhesives', completed: false, color: 'primary' },
    { name: 'Film', completed: false, color: 'primary' },
    { name: 'Rubber Sheet', completed: false, color: 'primary' },
  ];

  productStatus = [
    { name: 'Active', completed: false, color: 'primary' },
    { name: 'Inctive', completed: false, color: 'primary' }
  ];

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private _route: ActivatedRoute,
    private _productService: ProductService) { }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator!;
  }

  ngOnInit(): void {
    this._route.params.subscribe(params => {
      console.log('params : ', params);
      this.queryParams['type'] = params.type;
      this.queryParams['page'] = 0;
      this.queryParams['search'] = params.search;
      this.getMaterials();
    });

  }

  getMaterials() {
    this._productService.getMaterial(this.queryParams).subscribe((response: any) => {
      console.log('response : ', response);
      this.totalCount! = response.totalCount;
      this.material = response.data;
      this.dataSource = this.material;
    });
  }

  paginate(event: any) {
    console.log(event);
    this.queryParams['page'] = event.pageIndex;
    this.getMaterials();
  }

  doCheck(event: any, name: string) {
    console.log('event : ', event);
    console.log('name : ', name);
    this.queryParams['status'] = event.pageIndex;
    this.getMaterials();
  }

  setStatus() {
    console.log('productStatus : ', this.productStatus);
  }

}
