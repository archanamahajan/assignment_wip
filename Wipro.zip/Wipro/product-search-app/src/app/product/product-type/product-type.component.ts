import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstant } from '../../constants/app.const';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-product-type',
  templateUrl: './product-type.component.html',
  styleUrls: ['./product-type.component.css']
})
export class ProductTypeComponent implements OnInit {
  searchText = AppConstant.BROWSE_PRODUCT_HEADER;
  productTypes: any;

  constructor(private _productService: ProductService,
    private _router: Router) { }


  ngOnInit(): void {
    this._productService.getProductTypes().subscribe(response => {
      console.log('response : ', response);
      this.productTypes = response;
    });
  }

  onProductTypeClick(productType: string) {
    console.log('onProductTypeClick : ', productType);
    this._router.navigate(['/product-details', { type: productType }]);
  }
}
