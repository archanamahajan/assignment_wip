import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class ProductService {
    private readonly _APIURLPREFIX = '/api/product/';
    private readonly _APIURLAccessPrefix = {
        TYPES: 'types',
        MATERIAL: 'details'
    }
    constructor(private _http: HttpClient) { }

    getProductTypes() {
        const url = this._APIURLPREFIX + this._APIURLAccessPrefix.TYPES;
        return this._http.get(url);
    }

    getMaterial(queryParams: any) {
        // page=1&search=test&type=Foam&status=Active
        let url = this._APIURLPREFIX + this._APIURLAccessPrefix.MATERIAL + `?page=${queryParams.page}`;
        queryParams.type ? url += `&type=${queryParams.type}` : '';
        queryParams.search ? url += `&search=${queryParams.search}` : '';
        queryParams.status ? url += `&status=${queryParams.status}` : '';

        return this._http.get(url);
    }
}