import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductTypeComponent } from './product/product-type/product-type.component';
import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { AppComponent } from './app.component';

const routes: Routes = [
  { path: 'product-type', component: ProductTypeComponent },
  { path: 'product-details', component: ProductDetailsComponent },
  { path: '', component: ProductTypeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
