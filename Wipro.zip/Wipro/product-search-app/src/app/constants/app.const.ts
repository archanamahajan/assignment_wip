export class AppConstant {
    public static BROWSE_PRODUCT_HEADER = 'Browse By Product Type';
}