'use strict';
const url = require('url');

async function getProduct(req, res) {
    const db = req.app.locals.db;
    const productTypes = await db.collection('product').find().toArray();
    console.log('productTypes : ', productTypes);
    if (productTypes) {
        res.status(200).send(productTypes);
    } else {
        res.status(404).send({ error: 'Unable to fetch Product types' });
    }
}

async function getMaterial(req, res) {
    const db = req.app.locals.db;
    console.log('in getProductDetails');
    const queryObj = url.parse(req.url, true).query;
    console.log('queryObj : ', queryObj);
    const query = {
        productType: queryObj.type || { $exists: true },
        status: queryObj.status || { $exists: true }
    };
    if (queryObj.search) {
        query['name'] = { '$regex': `.*${queryObj.search}.*`, '$options': 'i' }
    }
    const page = queryObj.page || 1;
    const options = {
        limit: 10,
        skip: page * 10
    };
    // http://localhost:3000/api/product/details?page=1&search=test&type=Foam&status=Active
    const materialDetails = {};
    materialDetails['data'] = await db.collection('material').find(query, options).toArray();
    materialDetails['totalCount'] = await db.collection('material').find(query).count();
    if (materialDetails) {
        res.status(200).send(materialDetails);
    } else {
        res.status(404).send({ error: 'Unable to fetch Product details' });
    }
}

module.exports = {
    getProduct: getProduct,
    getMaterial: getMaterial
}