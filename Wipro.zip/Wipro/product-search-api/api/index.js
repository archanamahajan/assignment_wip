const express = require('express');
const { MongoClient } = require('mongodb');
const routes = require('./routes');

const app = express();
const port = 3000;

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    next();
});

/* 
    // Add headers before the routes are defined
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8888');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});
*/

app.use('/api', routes);

async function connectToDB() {
    const uri = "mongodb://localhost:27017/productInfo";
    const client = new MongoClient(uri);
    try {
        await client.connect();
        const db = client.db('productInfo');
        app.locals.db = db;
        console.log('Connected to DB : ', db);
        app.listen(port, () => {
            console.log(`product Search app listening on ${port}`);
        });
    } catch (e) {
        console.log('Could not connect to DB');
    } finally {
        // await client.close();
    }
}

connectToDB();
