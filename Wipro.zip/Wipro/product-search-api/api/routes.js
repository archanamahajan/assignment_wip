const express = require('express');
const product = require('./controller/product');
const router = express.Router();

router.get('/product/types', product.getProduct);
router.get('/product/details', product.getMaterial);

module.exports = router;